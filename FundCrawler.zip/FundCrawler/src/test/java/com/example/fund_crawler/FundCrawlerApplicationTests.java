package com.example.fund_crawler;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FundCrawlerApplicationTests {

	@Test
	void contextLoads() {
	}

}
